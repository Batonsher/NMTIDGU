from AlGaAs_2D import *
import tkinter


win = tkinter.Tk()

calc = Calculator(win, 'AlGaAs/GaAs/AlGaAs')


win.mainloop()

